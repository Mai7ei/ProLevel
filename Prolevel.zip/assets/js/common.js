$(document).ready(function(){

	$('.services_slider').slick({
		infinite: false,
        slidesToShow: 4,
        slidesToScroll: 1,
        // dots: true,
    	 appendDots: $(".slide-m-dots_services"),
        prevArrow: $(".slick-prev_services"),
        nextArrow: $(".slick-next_services"),
        responsive: [
        {
      breakpoint: 1370,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 1
      }
    },
    {
      breakpoint: 980,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 1
      }
    },
    {
      breakpoint: 780,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
    ]
	});

    $('.business_slider').slick({
        infinite: false,
        slidesToShow: 1,
        slidesToScroll: 1,
        // dots: true,
        appendDots: $(".slide-m-dots_develop"),
        prevArrow: $(".slick-prev_develop"),
        nextArrow: $(".slick-next_develop")
    })


			$(".info-wrapper .collapse").on('show.bs.collapse', function() {
      $(this).closest(".info-wrapper").find(".burger-menu").addClass("menu-on");
    });
			$(".info-wrapper .collapse").on('hide.bs.collapse', function() {
      $(this).closest(".info-wrapper").find(".burger-menu").removeClass("menu-on");
    });

    $('.portfolio_slider').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        centerMode: true,
        dots: true,
            prevArrow:'<div class="slider-arrow-prew"><i class="fas fa-arrow-left"></i></div>',
        nextArrow:'<div class="slider-arrow-next"><i class="fas fa-arrow-right"></i></div>'
    });

    $('.slider_portfolio_seo').slick({
        slidesToShow: 2,
        slidesToScroll: 1,
        // dots: true,
        // prevArrow:'<div class="slider-arrow-prew"><i class="fas fa-arrow-left"></i></div>',
        // nextArrow:'<div class="slider-arrow-next"><i class="fas fa-arrow-right"></i></div>'
        appendDots: $(".slide-dots_seo"),
        prevArrow: $(".slick-prev_seo"),
        nextArrow: $(".slick-next_seo"),
        responsive: [
        {
      breakpoint: 990,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
    ]
    });

    $('.slider_reviews').slick({
        infinite: false,
         slidesToShow: 4,
        slidesToScroll: 1,
        appendDots: $(".slide-dots_reviews"),
        prevArrow: $(".slick-prev_reviews"),
        nextArrow: $(".slick-next_reviews"),
        responsive: [
        {
      breakpoint: 980,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 1
      }
    },
    {
      breakpoint: 780,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 1
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
    ]
    });


	// $('.info-btn').click(function(){
	// 	$('.burger-menu').toggleClass('menu-on');

	// });

    // $('.sub_link').click(function(){
    //         $(this).removeClass('active'); 
    //         $(this).addClass('active');
    // });

    $('.sub_link span').on('click', function(){
    $('.sub_link').toggleClass('active');
    });

    $('.slider_blog').slick({
        slidesToShow: 1,
        prevArrow:'<div class="slider-arrow-prew"><i class="fas fa-arrow-left"></i></div>',
        nextArrow:'<div class="slider-arrow-next"><i class="fas fa-arrow-right"></i></div>'
    });

    $('.slider_portfolio_project').slick({
        slidesToShow: 1,
        prevArrow: $(".slick-prev_portfolio_project"),
        nextArrow: $(".slick-next_portfolio_project")
    });

    $('.header_nav_block').on('click', function() {

            $('#full_menu').toggleClass('open');


    });



});

